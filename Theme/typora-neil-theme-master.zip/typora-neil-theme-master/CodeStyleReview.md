### Code Style Review

[TOC]

### Java

```java
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        final List<Test> tests = new ArrayList<>(10);
        for (int i = 0; i < 10; i++) {
            System.out.println(i);
            tests.add(new Test());
        }

        for (Test item : tests) {
            System.out.println(item);
        }
    }

    @Data
    private static class Test {
        private int primitiveField = 1;
        private boolean primitiveTrue = true;
        private boolean primitiveFalse = false;
        private Integer fieldNum = 1;
        private final static String CONSTANT_STRING = "This is constant of string.";

        public int getPrimitiveField() {
            return primitiveField;
        }
    }
}

```

