# typora-neil-theme

#### 介绍
> typora的主题，主题文件主要放置在根目录下的[jetbrains-mono](./jetbrains-mono)目录。该主题主要用了JetBrains公司提供的字体JetBrainsMono，


#### 安装教程

- 打开typora的偏好设置。

> windows的快捷键为：“ctrl+,”，菜单路径为：文件->偏好设置；mac OS的快捷键为：“command+,”，菜单路径为：Typora->设置...；

- 找到“外观->打开主题文件夹”，快速打开typora的主题文件夹。
- 将[jetbrains-mono](./jetbrains-mono)目录下的css文件，以及和文件名相同文件夹，一并copy到第二步中打开的主题文件夹中。
- 重启typora。
- 在主题中找到对应的主题名进行切换即可。

> 主题名规则，将css文件名称中的“-”字符替换为空格，然后首字母改为大写。

#### 参与贡献

1.  Fork 本仓库
2.  新建 feat/20230316-xxx 分支，其中xxx为简要描述
3.  提交代码
4.  新建 Pull Request
